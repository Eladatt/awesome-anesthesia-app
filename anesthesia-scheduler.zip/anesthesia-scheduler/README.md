# Anesthesia Scheduling Platform

This platform provides a comprehensive solution for managing anesthesia department schedules.

## Features

- User authentication and authorization
- Schedule creation and management
- Career stage-specific lounges for communication
- Admin dashboard for user and schedule management

## Getting Started

### Prerequisites

- Node.js (v14+)
- MongoDB

### Installation

1. Clone the repository