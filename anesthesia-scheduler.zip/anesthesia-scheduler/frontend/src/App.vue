<template>
  <div id="app">
    <nav v-if="isLoggedIn">
      <router-link to="/">Home</router-link> |
      <router-link to="/schedule">Schedule</router-link> |
      <router-link to="/lounge">Lounge</router-link> |
      <router-link to="/profile">Profile</router-link> |
      <a href="#" @click.prevent="logout">Logout</a>
    </nav>
    <router-view/>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'

export default {
  name: 'App',
  computed: {
    ...mapGetters(['isLoggedIn'])
  },
  methods: {
    ...mapActions(['logout'])
  }
}
</script>