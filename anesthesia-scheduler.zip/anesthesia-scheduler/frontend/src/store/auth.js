import axios from 'axios'

const state = {
  token: localStorage.getItem('token') || '',
  user: JSON.parse(localStorage.getItem('user')) || null
}

const getters = {
  isLoggedIn: state => !!state.token,
  currentUser: state => state.user
}

const actions = {
  async login({ commit }, credentials) {
    try {
      const response = await axios.post('/auth/login', credentials)
      const { token, user } = response.data
      localStorage.setItem('token', token)
      localStorage.setItem('user', JSON.stringify(user))
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
      commit('setToken', token)
      commit('setUser', user)
    } catch (error) {
      console.error('Login error:', error)
      throw error
    }
  },
  async register({ commit }, userData) {
    try {
      const response = await axios.post('/auth/register', userData)
      const { token, user } = response.data
      localStorage.setItem('token', token)
      localStorage.setItem('user', JSON.stringify(user))
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
      commit('setToken', token)
      commit('setUser', user)
    } catch (error) {
      console.error('Registration error:', error)
      throw error
    }
  },
  logout({ commit }) {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    delete axios.defaults.headers.common['Authorization']
    commit('setToken', '')
    commit('setUser', null)
  }
}

const mutations = {
  setToken(state, token) {
    state.token = token
  },
  setUser(state, user) {
    state.user = user
  }
}

export default {
  state,
  getters,
  actions,
  mutations
}