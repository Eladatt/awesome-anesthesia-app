import Vue from 'vue'
import Vuex from 'vuex'
import auth from './modules/auth'
import schedule from './modules/schedule'
import lounge from './modules/lounge'

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    auth,
    schedule,
    lounge
  }
})