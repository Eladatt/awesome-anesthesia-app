import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios'

Vue.config.productionTip = false

// Set up axios for API calls
axios.defaults.baseURL = process.env.VUE_APP_API_URL
axios.interceptors.request.use(config => {
  const token = store.state.auth.token
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')