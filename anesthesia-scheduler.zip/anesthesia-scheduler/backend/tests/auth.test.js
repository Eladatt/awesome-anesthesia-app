const request = require('supertest')
const app = require('../server')
const User = require('../models/User')

beforeEach(async () => {
  await User.deleteMany({})
})

describe('Auth Endpoints', () => {
  it('should register a new user', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({
        username: 'testuser',
        password: 'password123',
        role: 'doctor',
        careerStage: 'resident',
        skills: ['anesthesia', 'pain management']
      })
    expect(res.statusCode).toEqual(200)
    expect(res.body).toHaveProperty('token')
    expect(res.body.user).toHaveProperty('username', 'testuser')
  })

  it('should login an existing user', async () => {
    await User.create({
      username: 'existinguser',
      password: 'password123',
      role: 'doctor',
      careerStage: 'resident'
    })

    const res = await request(app)
      .post('/api/auth/login')
      .send({
        username: 'existinguser',
        password: 'password123'
      })
    expect(res.statusCode).toEqual(200)
    expect(res.body).toHaveProperty('token')
    expect(res.body.user).toHaveProperty('username', 'existinguser')
  })
})