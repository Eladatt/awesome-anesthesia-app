const express = require('express')
const router = express.Router()
const { body, validationResult } = require('express-validator')
const auth = require('../middleware/auth')
const LoungeMessage = require('../models/LoungeMessage')

router.post('/', [auth, [
  body('message').isString().notEmpty(),
  body('careerStage').isIn(['attending', 'resident', 'intern', 'student'])
]], async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() })
  }

  try {
    const { message, careerStage } = req.body
    const loungeMessage = new LoungeMessage({
      user: req.user.id,
      message,
      careerStage
    })
    await loungeMessage.save()
    res.json(loungeMessage)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: 'Server error' })
  }
})

router.get('/:careerStage', auth, async (req, res) => {
  try {
    const messages = await LoungeMessage.find({ careerStage: req.params.careerStage })
      .sort({ createdAt: -1 })
      .populate('user', 'username')
    res.json(messages)
  }
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: 'Server error' })
  }
})

module.exports = router