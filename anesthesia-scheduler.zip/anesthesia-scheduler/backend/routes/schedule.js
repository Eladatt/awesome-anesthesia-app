const express = require('express')
const router = express.Router()
const { body, validationResult } = require('express-validator')
const auth = require('../middleware/auth')
const Schedule = require('../models/Schedule')

router.post('/', [auth, [
  body('date').isISO8601(),
  body('assignments').isArray(),
  body('assignments.*.place').isString(),
  body('assignments.*.staff').isArray()
]], async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() })
  }

  try {
    const { date, assignments } = req.body
    const schedule = new Schedule({
      date,
      assignments,
      createdBy: req.user.id
    })
    await schedule.save()
    res.json(schedule)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: 'Server error' })
  }
})

router.get('/', auth, async (req, res) => {
  try {
    const schedules = await Schedule.find().sort({ date: -1 }).populate('assignments.staff', 'username')
    res.json(schedules)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: 'Server error' })
  }
})

module.exports = router